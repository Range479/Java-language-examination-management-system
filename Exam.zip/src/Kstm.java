
public class Kstm {
	private int no;
	private int id;
	private double fen;
	private int t;
	private int f;
	
	public Kstm(int no, int id, double fen, int t, int f) {
		super();
		this.no = no;
		this.id = id;
		this.fen = fen;
		this.t = t;
		this.f = f;
	}
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getFen() {
		return fen;
	}
	public void setFen(double fen) {
		this.fen = fen;
	}
	public int getT() {
		return t;
	}
	public void setT(int t) {
		this.t = t;
	}
	public int getF() {
		return f;
	}
	public void setF(int f) {
		this.f = f;
	}
	
	
}
